<template>
  <div>
    <div class="header">
      <span v-if="open" @click="open = !open">&#x25B2; Collapse</span>
      <span v-if="!open" @click="open = !open">&#x25BC; Expand</span>
    </div>
    <!-- /.header -->
    <slot v-if="open">
    </slot>
  </div>
</template>
<script>
export default {
  name: 'CollapsibleSection',
  data() {
    return {
      open: true
    }
  }
}
</script>
<style lang="scss" scoped>
.header {
  background-color: #bbb;
  cursor: pointer;
  padding: 5px;
}
</style>

